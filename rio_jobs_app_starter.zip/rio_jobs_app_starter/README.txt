RIO Jobs — app starter (Zambia)

INCLUDED
- Rebranded responsive job-board prototype named RIO Jobs.
- Existing sample vacancy listings and search filters.
- RIO Jobs logo (without HMK).
- PWA manifest, service worker, and 192/512px app icons.
- Can be hosted as a website and installed on compatible Android devices from the browser.

IMPORTANT LIMITATIONS
- Sample vacancies are fictional and labelled as samples.
- Employer form is a demo only and does not save or transmit information.
- No real login, database, CV upload, applications, admin moderation, or payments yet.
- This ZIP is NOT an Android APK or Play Store release file.
- A public, secure HTTPS hosting address is required for normal PWA installation.
- Publishing on Google Play requires a Google Play Console developer account, a signed Android App Bundle (AAB), store listing assets, privacy policy/data-safety disclosures, testing, and compliance with current Play policies.
- Before accepting real users, connect a secure backend, real vacancies, employer verification, reporting/moderation, and privacy/security controls.

NEXT STEPS
1. Preview index.html in a browser.
2. Put this project on HTTPS hosting to test installability as a PWA.
3. Connect database/authentication and build the real application workflow.
4. Package the finished web app for Android using a suitable Android wrapper (for example, Trusted Web Activity when the hosted site meets its requirements, or a native/cross-platform app).
5. Test, sign, and submit the Android App Bundle through Play Console.
